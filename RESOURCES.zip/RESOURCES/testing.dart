// // ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables

// import 'package:flutter/material.dart';
// import 'package:firebase_core/firebase_core.dart';
// import 'package:firebase_auth/firebase_auth.dart';

// void main() async {
//   WidgetsFlutterBinding.ensureInitialized();
//   await Firebase.initializeApp();
//   runApp(const MyApp());
// }

// // controllers

// // validation

// // clearInputs

// class MyApp extends StatefulWidget {
//   const MyApp({Key? key}) : super(key: key);

//   @override
//   State<MyApp> createState() => _MyAppState();
// }

// class _MyAppState extends State<MyApp> {
//   final emailController = TextEditingController();
//   final passwordController = TextEditingController();
//   final GlobalKey<FormState> _key = GlobalKey<FormState>();
//   String errorMessage = '';
//   bool isLoading = false;

//   String? validateEmail(String? formEmail) {
//     if (formEmail == null || formEmail.isEmpty) {
//       return 'E-mail adress is required';
//     }
//     return null;
//   }

//   String? validatePassword(String? formPassword) {
//     if (formPassword == null || formPassword.isEmpty) {
//       return 'Password is required';
//     }
//     return null;
//   }

//   void clearLoginInputs() {
//     emailController.clear();
//     passwordController.clear();
//   }

//   @override
//   Widget build(BuildContext context) {
//     User? user = FirebaseAuth.instance.currentUser;
//     return MaterialApp(
//       home: Scaffold(
//         appBar: AppBar(
//           title: Text('Logged  ${user == null ? 'out' : 'in'}'),
//         ),
//         body: Container(
//           padding: EdgeInsets.all(20),
//           child: SingleChildScrollView(
//             child: Column(
//               mainAxisAlignment: MainAxisAlignment.center,
//               children: [
//                 Form(
//                   key: _key,
//                   child: SizedBox(
//                     height: 400,
//                     child: Column(
//                       mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                       children: [
//                         SizedBox(height: 40),
//                         if (errorMessage.isNotEmpty)
//                           Card(
//                               elevation: 0,
//                               color: Colors.red[400],
//                               child: Padding(
//                                 padding: const EdgeInsets.all(8.0),
//                                 child: Text(
//                                   errorMessage,
//                                   style: TextStyle(color: Colors.white),
//                                 ),
//                               )),
//                         SizedBox(height: 40),
//                         Column(
//                           children: [
//                             TextFormField(
//                               controller: emailController,
//                               validator: validateEmail,
//                               decoration: InputDecoration(
//                                   border: OutlineInputBorder(),
//                                   prefixIcon: Icon(Icons.alternate_email),
//                                   hintText: 'Enter your email'),
//                             ),
//                             SizedBox(height: 20),
//                             TextFormField(
//                               controller: passwordController,
//                               validator: validatePassword,
//                               decoration: InputDecoration(
//                                   border: OutlineInputBorder(),
//                                   prefixIcon: Icon(Icons.lock),
//                                   hintText: 'Enter your password'),
//                             ),
//                           ],
//                         ),
//                         Row(
//                           mainAxisAlignment: MainAxisAlignment.spaceAround,
//                           children: [
//                             ElevatedButton(
//                                 child: isLoading
//                                     ? Text('Loading..')
//                                     : Text('Log In'),
//                                 onPressed: user == null
//                                     ? () async {
//                                         setState(() => isLoading = true);
//                                         if (_key.currentState!.validate()) {
//                                           try {
//                                             await FirebaseAuth.instance
//                                                 .signInWithEmailAndPassword(
//                                               email: emailController.text,
//                                               password: passwordController.text,
//                                             );

//                                             errorMessage = '';
//                                           } on FirebaseAuthException catch (error) {
//                                             errorMessage = error.message!;
//                                           }
//                                           setState(() {
//                                             setState(() => isLoading = false);
//                                           });
//                                         }
//                                       }
//                                     : null),
//                             ElevatedButton(
//                               child: isLoading
//                                   ? Text('Loading..')
//                                   : Text('Sign Up'),
//                               onPressed: user != null
//                                   ? null
//                                   : () async {
//                                       setState(() => isLoading = true);
//                                       if (_key.currentState!.validate()) {
//                                         try {
//                                           await FirebaseAuth.instance
//                                               .createUserWithEmailAndPassword(
//                                                   email: emailController.text,
//                                                   password:
//                                                       passwordController.text);
//                                           errorMessage = '';
//                                         } on FirebaseAuthException catch (error) {
//                                           errorMessage = error.message!;
//                                         }

//                                         setState(() {
//                                           isLoading = false;
//                                         });
//                                       }
//                                     },
//                             ),
//                             OutlinedButton(
//                               onPressed: user == null
//                                   ? null
//                                   : () {
//                                       setState(() {
//                                         isLoading = true;
//                                       });
//                                       try {
//                                         FirebaseAuth.instance.signOut();
//                                         errorMessage = '';
//                                       } on FirebaseException catch (error) {
//                                         errorMessage = error.message!;
//                                       }
//                                       setState(() {
//                                         isLoading = false;
//                                         clearLoginInputs();
//                                       });
//                                     },
//                               child: isLoading
//                                   ? Text('Loading..')
//                                   : Text('Log Out'),
//                             )
//                           ],
//                         ),
//                       ],
//                     ),
//                   ),
//                 )
//               ],
//             ),
//           ), // Column
//         ), //
//       ),
//     );
//   }
// }
