import 'package:flutter/material.dart';

Widget appBar(String text, IconButton iconButton1, IconButton iconButton2) {
  return AppBar(
    title: Text(
      text,
      style: TextStyle(color: Colors.black),
    ),
    centerTitle: false,
    actions: [iconButton1, iconButton2],
    automaticallyImplyLeading: false,
    backgroundColor: Colors.transparent,
    elevation: 0,
  );
}
